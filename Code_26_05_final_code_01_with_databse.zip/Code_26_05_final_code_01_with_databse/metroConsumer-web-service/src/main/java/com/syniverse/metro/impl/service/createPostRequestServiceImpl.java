package com.syniverse.metro.impl.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.syniverse.metro.dto.model.Tutorial;
import com.syniverse.metro.dto.repository.TutorialRepository;
import com.syniverse.metro.neustar.xsd.sea.ESROrder;
import com.syniverse.metro.service.createPortRequestService;
import com.syniverse.metro.tnd.xsd.generated.PORTREQUESTType;
import com.syniverse.metro.tnd.xsd.generated.WnpLINEDATAType;
import com.syniverse.metro.util.XMLUtil;

@Component
public class createPostRequestServiceImpl implements createPortRequestService {

	@Autowired
	TutorialRepository tutorialRepository;

	@Override
	public void createPostRequestMapping(ESROrder request) {
		// TODO Auto-generated method stub

		PORTREQUESTType portrequestType = new PORTREQUESTType();

		System.out.println("request " + request);

		WnpLINEDATAType wnpLINEDATAType = new WnpLINEDATAType();
		wnpLINEDATAType.setLNUM(request.getCustomerDetails().getProductDetails().getLRN());
		ArrayList<WnpLINEDATAType> arrayList = new ArrayList<WnpLINEDATAType>();
		arrayList.add(wnpLINEDATAType);
		portrequestType.setLinedata(arrayList);

		System.out.println("TND request " + portrequestType.getLINEDATA().get(0).getLNUM());

		String xml = XMLUtil.toXML(portrequestType);
		System.out.println("Pojo to XML");
		System.out.println(xml);

		// Database
		try {
			Tutorial tutorial = new Tutorial();
			tutorialRepository
					.save(new Tutorial(007,"praveenkumar","kodge",false));
			System.out.println("Tutorial was created successfully.");
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
