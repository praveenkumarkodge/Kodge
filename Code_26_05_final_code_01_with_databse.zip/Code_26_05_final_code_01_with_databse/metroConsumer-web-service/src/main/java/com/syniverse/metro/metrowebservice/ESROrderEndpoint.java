package com.syniverse.metro.metrowebservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.syniverse.metro.impl.service.createPostRequestServiceImpl;
import com.syniverse.metro.neustar.xsd.sea.ESROrder;
import com.syniverse.metro.neustar.xsd.sea.ResponseDetailsType;
import com.syniverse.metro.neustar.xsd.sea.ESROrder.OrderDetails;

@Endpoint
public class ESROrderEndpoint {

	private static final String NAMESPACE_URI = "http://www.neustar.com/xsd/sea";

	@Autowired
	createPostRequestServiceImpl createPostRequestServiceImpl;

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "ESROrder")
	@ResponsePayload
	public ESROrder CreatePortRequest(@RequestPayload ESROrder request) {

		ESROrder ESROrder = new ESROrder();

		String ServiceName = request.getOrderDetails().getNodeList().getNodeName().get(0);
		System.out.println(ServiceName);
		if (ServiceName.equals("createPortRequest")) {
			System.out.println("Service  " + ServiceName);
			// Request body

			createPostRequestServiceImpl.createPostRequestMapping(request);

			// Response body
			OrderDetails orderDetails = new OrderDetails();
			ResponseDetailsType ResponseDetailsType = new ResponseDetailsType();
			ResponseDetailsType.setStatus("ack");
			orderDetails.setResponseDetails(ResponseDetailsType);
			ESROrder.setOrderDetails(orderDetails);

		}else {
			System.out.println("Not a valid Response");
			OrderDetails orderDetails = new OrderDetails();
			ResponseDetailsType ResponseDetailsType = new ResponseDetailsType();
			ResponseDetailsType.setStatus("nack");
			orderDetails.setResponseDetails(ResponseDetailsType);
			ESROrder.setOrderDetails(orderDetails);
		}

		return ESROrder;
	}
}
