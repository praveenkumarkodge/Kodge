package com.syniverse.metro.service;

import org.springframework.stereotype.Component;

import com.syniverse.metro.neustar.xsd.sea.ESROrder;

@Component
public interface createPortRequestService {
	
	public void createPostRequestMapping(ESROrder request);

}
