package com.syniverse.metro.util;

import java.io.StringWriter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class XMLUtil {

	public static String toXML(Object data) {
		String xml = "";
		try {
			System.out.println("data"+data);
			JAXBContext jaxbContext = JAXBContext.newInstance(data.getClass());
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			// jaxbMarshaller.marshal(data, System.out);
			StringWriter sw = new StringWriter();
			jaxbMarshaller.marshal(data, sw);
			System.out.println("sw"+sw);
			xml = sw.toString();
		} catch (JAXBException e) {
			System.out.println(e);
		}
		return xml;
	}

}